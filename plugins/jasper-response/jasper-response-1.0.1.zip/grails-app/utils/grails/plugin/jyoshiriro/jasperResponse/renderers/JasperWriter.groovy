package grails.plugin.jyoshiriro.jasperResponse.renderers

import java.io.Writer;

class JasperWriter {
	Writer writer;
}
